#!/usr/bin/env python3
"""
Regenerate every handbook diagram.

Design constraint: the text column is 174 mm (493 pt) wide. A diagram authored
in a viewBox W units wide renders its type at  size * 493 / W  points.
With W = 620, a 11-unit label prints at ~8.7 pt and a 13-unit label at ~10.3 pt,
which is legible on A4 and in greyscale. Every layout below is therefore built
for 620 units of width; height is unconstrained because pages scroll.
"""
import pathlib

OUT = pathlib.Path(__file__).parent
W = 620

IND, VIO, LAV = "#171338", "#7657F6", "#F4F1FF"
INK, INK2, RULE = "#26233D", "#625E78", "#E5E1F0"
OK, OKT = "#157B55", "#E6F4ED"
WARN, WARNT = "#9D5E11", "#FBF0E0"
STOP, STOPT = "#B42318", "#FCEBE9"
LILAC = "#B9A8F7"

# type scale, in viewBox units -> printed pt at 493/620
T_TITLE, T_SUB, T_HEAD, T_BODY, T_SMALL = 15, 11.5, 13, 11, 9.8


def head(h, title, sub=None):
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {h}" font-family="Inter">',
         f'<rect width="{W}" height="{h}" fill="#FFFFFF"/>',
         f'<text x="12" y="19" font-size="{T_TITLE}" font-weight="700" fill="{IND}">{title}</text>']
    if sub:
        o.append(f'<text x="12" y="35" font-size="{T_SMALL}" fill="{INK2}">{sub}</text>')
    return o


def wrap(text, width_units, size):
    """Greedy wrap by estimated glyph width (~0.52 em for Inter at these sizes)."""
    per = size * 0.52
    maxch = max(6, int(width_units / per))
    words, lines, cur = text.split(), [], ""
    for wd in words:
        t = (cur + " " + wd).strip()
        if len(t) > maxch and cur:
            lines.append(cur)
            cur = wd
        else:
            cur = t
    if cur:
        lines.append(cur)
    return lines


def box(x, y, w, h, title, body=None, kind="n", rx=5):
    if kind == "a":
        fill, stroke, tc, sc, sw = VIO, VIO, "#FFFFFF", "#DCD2FF", 1.6
    elif kind == "t":
        fill, stroke, tc, sc, sw = LAV, LILAC, IND, INK2, 1
    elif kind == "ok":
        fill, stroke, tc, sc, sw = OKT, OK, OK, OK, 1
    elif kind == "bad":
        fill, stroke, tc, sc, sw = STOPT, STOP, STOP, STOP, 1
    elif kind == "dark":
        fill, stroke, tc, sc, sw = IND, IND, "#FFFFFF", "#C9BEF8", 1
    elif kind == "ghost":
        fill, stroke, tc, sc, sw = "#FFFFFF", RULE, INK2, INK2, 1
    else:
        fill, stroke, tc, sc, sw = "#FFFFFF", RULE, IND, INK2, 1
    dash = ' stroke-dasharray="4 3"' if kind == "ghost" else ""
    o = [f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" '
         f'stroke="{stroke}" stroke-width="{sw}"{dash}/>']
    ty = y + 17
    for ln in wrap(title, w - 16, T_BODY):
        o.append(f'<text x="{x+8}" y="{ty}" font-size="{T_BODY}" font-weight="700" fill="{tc}">{ln}</text>')
        ty += 13
    if body:
        ty += 1
        for ln in wrap(body, w - 16, T_SMALL):
            o.append(f'<text x="{x+8}" y="{ty}" font-size="{T_SMALL}" fill="{sc}">{ln}</text>')
            ty += 11.5
    return "".join(o), ty


def arrow(x1, y1, x2, y2, col=INK2, dash=False, mid=None, midcol=None, dy=-5):
    d = ' stroke-dasharray="4 3"' if dash else ""
    o = [f'<path d="M{x1} {y1}L{x2} {y2}" stroke="{col}" stroke-width="1.2"{d} marker-end="url(#ar)"/>']
    if mid:
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2 + dy
        for i, ln in enumerate(mid.split("\n")):
            o.append(f'<text x="{mx}" y="{my+i*11}" text-anchor="middle" font-size="{T_SMALL}" '
                     f'fill="{midcol or col}">{ln}</text>')
    return "".join(o)


def defs(*cols):
    m = []
    for c in set(cols) | {INK2}:
        i = c.replace("#", "")
        m.append(f'<marker id="ar{i}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5.5" '
                 f'markerHeight="5.5" orient="auto"><path d="M0 0L10 5L0 10z" fill="{c}"/></marker>')
    m.append('<marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5.5" markerHeight="5.5" '
             f'orient="auto"><path d="M0 0L10 5L0 10z" fill="{INK2}"/></marker>')
    return "<defs>" + "".join(m) + "</defs>"


def save(name, parts, h):
    parts.append(defs(VIO, OK, STOP, WARN, LILAC))
    parts.append("</svg>")
    (OUT / f"{name}.svg").write_text("".join(parts))
    print(f"  {name}.svg  ({W}x{h})")


def pill(x, y, text, fg, bg, size=None):
    size = size or 9
    w = len(text) * size * 0.58 + 12
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{size+7}" rx="{(size+7)/2}" fill="{bg}"/>'
            f'<text x="{x+w/2}" y="{y+size+1}" text-anchor="middle" font-size="{size}" '
            f'font-weight="700" fill="{fg}">{text}</text>'), w


# ---------------------------------------------------------------- 1. module map
def module_map():
    groups = [
        ("Discovery", [("1", "Public property discovery", "F"), ("2", "Property listings & details", "F")]),
        ("Inventory &\nspatial", [("3", "Organisation & multi-property", "P"), ("4", "Buildings, floors, rooms, beds", "P"),
                                  ("5", "Interactive 2D floor plan", "P"), ("6", "3D building map", "F"),
                                  ("7", "Availability & occupancy", "P")]),
        ("Acquisition", [("8", "Enquiry & prospect workflow", "L"), ("9", "Phone verification", "L"),
                         ("10", "Booking, admission & allocation", "P")]),
        ("Residents", [("11", "Resident profiles & lifecycle", "P"), ("12", "Document management", "F")]),
        ("Finance", [("13", "Rent & recurring charges", "P"), ("14", "Manual payment recording", "P"),
                     ("15", "Payment reconciliation", "P"), ("16", "Deposits, refunds & checkout", "P")]),
        ("Operations", [("17", "Maintenance requests", "L"), ("18", "Complaints & incidents", "L"),
                        ("19", "Housekeeping & inspections", "F")]),
        ("Platform", [("20", "Staff, roles & permissions", "P"), ("21", "Notifications & communication", "L"),
                      ("22", "Reporting & dashboards", "P"), ("23", "SaaS organisation admin", "F"),
                      ("24", "Subscription entitlements", "F"), ("25", "Audit & platform admin", "P")]),
    ]
    LBL, COLS, CW, CH, GX, GY = 86, 3, 166, 40, 8, 7
    rows, y = [], 48
    for g, mods in groups:
        n = (len(mods) + COLS - 1) // COLS
        h = n * CH + (n - 1) * GY
        rows.append((g, mods, y, h))
        y += h + 12
    H = y + 34
    p = head(H, "The Nook module map",
             "Solid violet = proposed pilot scope · tinted = next release · outlined = later phase")
    for g, mods, gy, gh in rows:
        p.append(f'<rect x="0" y="{gy}" width="{LBL-8}" height="{gh}" rx="4" fill="{LAV}"/>')
        gl = g.split("\n")
        for i, ln in enumerate(gl):
            p.append(f'<text x="8" y="{gy+gh/2+4-(len(gl)-1)*6+i*12}" font-size="{T_BODY}" '
                     f'font-weight="700" fill="{IND}">{ln}</text>')
        for i, (num, label, ph) in enumerate(mods):
            r, c = divmod(i, COLS)
            x, yy = LBL + c * (CW + GX), gy + r * (CH + GY)
            if ph == "P":
                f, s, tc, nc = VIO, VIO, "#FFFFFF", "#DCD2FF"
            elif ph == "L":
                f, s, tc, nc = LAV, LILAC, IND, VIO
            else:
                f, s, tc, nc = "#FFFFFF", RULE, INK2, "#9585C2"
            p.append(f'<rect x="{x}" y="{yy}" width="{CW}" height="{CH}" rx="4" fill="{f}" stroke="{s}"/>')
            p.append(f'<text x="{x+8}" y="{yy+15}" font-size="{T_SMALL}" font-weight="700" fill="{nc}">{num}</text>')
            lines = wrap(label, CW - 34, T_BODY)[:2]
            ty = yy + 16 if len(lines) == 1 else yy + 14
            for j, ln in enumerate(lines):
                p.append(f'<text x="{x+24}" y="{ty+j*12.5}" font-size="{T_BODY}" font-weight="600" fill="{tc}">{ln}</text>')
    ly = H - 18
    lx = 0
    for lab, f, s in [("Pilot", VIO, VIO), ("Next release", LAV, LILAC), ("Later phase", "#FFFFFF", RULE)]:
        p.append(f'<rect x="{lx}" y="{ly}" width="15" height="11" rx="2.5" fill="{f}" stroke="{s}"/>')
        p.append(f'<text x="{lx+21}" y="{ly+9.5}" font-size="{T_SMALL}" fill="{INK2}">{lab}</text>')
        lx += len(lab) * 5.6 + 54
    save("module-map", p, H)


# ------------------------------------------------------------------- 2. journey
def journey():
    stages = [("Discover", "Public search,\nproperty detail", "v"),
              ("Explore layout", "2D plan, bed\npositions", "v"),
              ("Enquire", "Contact + phone\nverification", "p"),
              ("Select bed", "Choose a specific\nbed on the map", "p"),
              ("Approval", "Staff review\nand decision", "s"),
              ("Allocate", "Atomic commit,\navailability re-checked", "y"),
              ("Check in", "Move-in recorded,\nterms attached", "s"),
              ("Live", "Charges, payments,\nrequests", "p"),
              ("Check out", "Operational exit,\nthen settlement", "s")]
    fails = ["Leaves", "Leaves", "Abandons", "Bed taken", "Rejected", "Conflict → reselect",
             "No-show", "Arrears", "Dispute"]
    sty = {"v": "ghost", "p": "t", "s": "a", "y": "dark"}
    COLS, BW, BH, GX, GY, LM = 3, 186, 56, 16, 50, 12
    nrow = 3
    H = 52 + nrow * (BH + GY) + 18
    p = head(H, "Discovery to stay — the end-to-end journey",
             "Dashed branches are the alternative outcome each step must handle.")
    for i, (t, s, who) in enumerate(stages):
        r, c = divmod(i, COLS)
        x = LM + c * (BW + GX)
        y = 52 + r * (BH + GY)
        b, _ = box(x, y, BW, BH, t, s.replace("\n", " "), sty[who])
        p.append(b)
        p.append(f'<text x="{x+BW-8}" y="{y+15}" text-anchor="end" font-size="{T_SMALL}" '
                 f'font-weight="700" fill="{"#DCD2FF" if who in "sy" else INK2}">{i+1}</text>')
        # failure branch
        p.append(f'<path d="M{x+16} {y+BH}V{y+BH+12}" stroke="{WARN}" stroke-width="1" stroke-dasharray="3 2"/>')
        p.append(f'<text x="{x+24}" y="{y+BH+16}" font-size="{T_SMALL}" fill="{WARN}">{fails[i]}</text>')
        if i == len(stages) - 1:
            pass
        elif c < COLS - 1:
            p.append(arrow(x + BW + 2, y + BH / 2, x + BW + GX - 4, y + BH / 2))
        else:
            gy, nyy = y + BH + GY - 13, y + BH + GY + BH / 2
            p.append(f'<path d="M{x+BW} {y+BH/2}H{x+BW+6}V{gy}H4V{nyy}H{LM-6}" fill="none" '
                     f'stroke="{INK2}" stroke-width="1.1" marker-end="url(#ar)"/>')
    leg = [("Public visitor", "#FFFFFF", RULE), ("Prospect / resident", LAV, LILAC),
           ("Staff action", VIO, VIO), ("System guarantee", IND, IND)]
    lx, ly = 0, H - 10
    for lab, f, s in leg:
        p.append(f'<rect x="{lx}" y="{ly-9}" width="14" height="10" rx="2.5" fill="{f}" stroke="{s}"/>')
        p.append(f'<text x="{lx+20}" y="{ly}" font-size="{T_SMALL}" fill="{INK2}">{lab}</text>')
        lx += len(lab) * 5.4 + 46
    save("journey", p, H)


# -------------------------------------------------------- 3. spatial hierarchy
def spatial_hierarchy():
    chain = [("Property", "The premises. One address.", "1"),
             ("Building", "A structure. Often exactly one.", "1..n"),
             ("Floor", "A level. Orders vertically.", "1..n"),
             ("Room", "An enclosed space. Has a label.", "1..n"),
             ("Bed", "The allocatable unit. Has a position.", "1..n")]
    BW, BH, GY = 300, 46, 14
    H = 52 + len(chain) * (BH + GY) + 74
    p = head(H, "Spatial hierarchy — identity, containment and position",
             "Only the bed is allocated, and only the bed carries a position on a layout.")
    for i, (t, s, card) in enumerate(chain):
        y = 52 + i * (BH + GY)
        x = i * 26
        b, _ = box(x, y, BW, BH, t, s, "a" if i == 4 else "n")
        p.append(b)
        if i < 4:
            p.append(arrow(x + 22, y + BH + 1, x + 26 + 22, y + BH + GY - 3))
            p.append(f'<text x="{x+62}" y="{y+BH+12}" font-size="{T_SMALL}" fill="{INK2}">{chain[i+1][2]}</text>')
    ly = 52 + len(chain) * (BH + GY) + 6
    p.append(f'<rect x="0" y="{ly}" width="{W}" height="58" rx="5" fill="{LAV}" stroke="{LILAC}" stroke-dasharray="4 3"/>')
    p.append(f'<text x="12" y="{ly+19}" font-size="{T_HEAD}" font-weight="700" fill="{IND}">Spatial layout version</text>')
    for j, ln in enumerate(wrap("Effective-dated geometry for one floor: room outlines, corridors and an x/y "
                                "position for every bed. Versioned, so a re-plan never rewrites where a past "
                                "resident actually slept.", W - 24, T_SMALL)):
        p.append(f'<text x="12" y="{ly+34+j*12}" font-size="{T_SMALL}" fill="{INK}">{ln}</text>')
    p.append(arrow(4 * 26 + 150, 52 + 4 * (BH + GY) + BH + 1, 4 * 26 + 150, ly - 3, LILAC, True))
    save("spatial-hierarchy", p, H)


# ------------------------------------------------------------ 4. shared spatial
def shared_spatial():
    H = 266
    p = head(H, "One spatial model, two renderers",
             "The 3D view is an additional renderer over the same records. No second source of truth.")
    rend = [("2D floor plan", "SVG / Canvas", "PILOT", True), ("Accessible list", "Semantic HTML", "PILOT", True),
            ("3D building view", "WebGL", "FUTURE", False)]
    BW, GX = 194, 19
    for i, (n, tech, ph, now) in enumerate(rend):
        x = i * (BW + GX)
        b, ty = box(x, 50, BW, 64, n, tech, "n" if now else "ghost")
        p.append(b)
        pl, pw = pill(x + 8, ty - 2, ph, OK if now else WARN, OKT if now else WARNT)
        p.append(pl)
        p.append(arrow(x + BW / 2, 116, x + BW / 2, 128, INK2 if now else LILAC, not now))
    p.append(f'<rect x="60" y="130" width="{W-120}" height="52" rx="5" fill="{VIO}"/>')
    p.append(f'<text x="{W/2}" y="152" text-anchor="middle" font-size="{T_HEAD}" font-weight="700" '
             f'fill="#FFFFFF">Spatial &amp; availability service</text>')
    p.append(f'<text x="{W/2}" y="169" text-anchor="middle" font-size="{T_SMALL}" fill="#E3DAFF">'
             f'Resolves layout + live bed state · enforces organisation scope</text>')
    p.append(arrow(W / 2, 184, W / 2, 202))
    p.append(f'<rect x="0" y="204" width="{W}" height="54" rx="5" fill="{IND}"/>')
    p.append(f'<text x="12" y="224" font-size="{T_HEAD}" font-weight="700" fill="#FFFFFF">'
             f'PostgreSQL — authoritative records</text>')
    items = ["Bed", "Room / Floor", "Layout version", "Assignment", "Stay"]
    ix = 12
    for it in items:
        w = len(it) * 5.4 + 18
        p.append(f'<rect x="{ix}" y="232" width="{w}" height="18" rx="3.5" fill="rgba(255,255,255,0.12)" '
                 f'stroke="rgba(255,255,255,0.28)"/>')
        p.append(f'<text x="{ix+w/2}" y="245" text-anchor="middle" font-size="{T_SMALL}" fill="#D9CEFF">{it}</text>')
        ix += w + 7
    save("shared-spatial", p, H)


# ------------------------------------------------------------ 5. booking states
def booking_states():
    main = [("Enquiry", "n"), ("Verified", "n"), ("Bed selected", "n"),
            ("Pending review", "n"), ("Approved", "a"), ("Allocated", "a"),
            ("Checked in", "a"), ("Active stay", "a"), ("Notice given", "n"),
            ("Checkout pending", "n"), ("Checked out", "ok")]
    fails = {0: "Abandoned", 1: "Verification failed", 2: "Bed taken \u2192 reselect",
             3: "Rejected", 4: "Expired", 5: "Cancelled / no-show"}
    COLS, BW, BH, GX, GY, LM = 3, 188, 38, 16, 48, 12
    nrow = (len(main) + COLS - 1) // COLS
    H = 52 + nrow * (BH + GY) + 76
    p = head(H, "Booking and allocation \u2014 state machine",
             "Violet states are the committed path. Dashed exits depend on rules that are still open.")
    for i, (t, k) in enumerate(main):
        r, c = divmod(i, COLS)
        x, y = LM + c * (BW + GX), 52 + r * (BH + GY)
        p.append(f'<rect x="{x}" y="{y}" width="{BW}" height="{BH}" rx="5" '
                 f'fill="{VIO if k=="a" else (OKT if k=="ok" else "#FFFFFF")}" '
                 f'stroke="{VIO if k=="a" else (OK if k=="ok" else RULE)}" stroke-width="{1.5 if k!="n" else 1}"/>')
        tc = "#FFFFFF" if k == "a" else (OK if k == "ok" else IND)
        p.append(f'<text x="{x+BW/2}" y="{y+BH/2+4}" text-anchor="middle" font-size="{T_BODY}" '
                 f'font-weight="700" fill="{tc}">{t}</text>')
        if i in fails:
            p.append(f'<path d="M{x+BW/2} {y+BH}V{y+BH+10}" stroke="{STOP}" stroke-width="1" stroke-dasharray="3 2"/>')
            p.append(f'<text x="{x+BW/2}" y="{y+BH+21}" text-anchor="middle" font-size="{T_SMALL}" '
                     f'fill="{STOP}">{fails[i]}</text>')
        if i == len(main) - 1:
            continue
        if c < COLS - 1:
            p.append(arrow(x + BW + 2, y + BH / 2, x + BW + GX - 4, y + BH / 2))
        else:
            gy = y + BH + GY - 12
            ny = y + BH + GY + BH / 2
            p.append(f'<path d="M{x+BW} {y+BH/2}H{x+BW+6}V{gy}H4V{ny}H{LM-6}" fill="none" '
                     f'stroke="{INK2}" stroke-width="1.1" marker-end="url(#ar)"/>')
    ny = 52 + nrow * (BH + GY) + 12
    p.append(f'<rect x="0" y="{ny}" width="{W}" height="54" rx="5" fill="{WARNT}" stroke="{WARN}" stroke-width="0.8"/>')
    p.append(f'<text x="12" y="{ny+19}" font-size="{T_BODY}" font-weight="700" fill="{WARN}">'
             f'Financial settlement is a separate workflow</text>')
    for j, ln in enumerate(wrap("Checked out is an operational state. It changes no balance, nets no deposit and "
                                "releases no bed until the approved effective-date rule exists.", W - 24, T_SMALL)):
        p.append(f'<text x="12" y="{ny+34+j*12}" font-size="{T_SMALL}" fill="{WARN}">{ln}</text>')
    save("booking-states", p, H)


# ------------------------------------------------------------- 6. finance model
def finance_model():
    H = 300
    p = head(H, "Six record types — and the one derived number",
             "Nothing posted is ever edited or deleted. The balance is computed, never stored as truth.")
    cards = [("Charge", "A claim for a period. Amount frozen at issue.", 0, 50),
             ("Payment", "Money that arrived. Method + reference.", 212, 50),
             ("Allocation", "Links one payment to one charge, for an amount.", 424, 50),
             ("Adjustment", "Signed correction with reason and approver.", 0, 112),
             ("Reversal", "Negates a posted record. Original stays visible.", 212, 112),
             ("Deposit", "A liability. Never allocated to a charge.", 424, 112)]
    for t, s, x, y in cards:
        kind = "a" if t == "Allocation" else ("ok" if t == "Deposit" else "t")
        b, _ = box(x, y, 196, 52, t, s, kind)
        p.append(b)
    p.append(f'<rect x="0" y="178" width="{W}" height="54" rx="5" fill="{IND}"/>')
    p.append(f'<text x="12" y="198" font-size="{T_HEAD}" font-weight="700" fill="#FFFFFF">'
             f'Outstanding balance — derived every time</text>')
    p.append(f'<text x="12" y="220" font-family="DejaVu Sans Mono" font-size="{T_BODY}" fill="#C9BEF8">'
             f'Σ charges + Σ debit adj − Σ allocations − Σ credit adj</text>')
    p.append(f'<rect x="0" y="240" width="{W}" height="54" rx="5" fill="{STOPT}" stroke="{STOP}" stroke-width="0.8"/>')
    p.append(f'<text x="12" y="259" font-size="{T_BODY}" font-weight="700" fill="{STOP}">'
             f'Money is integer paise in BIGINT — never binary floating point</text>')
    for j, ln in enumerate(wrap('API carries amountMinor as a base-10 integer string with an explicit currency: '
                                '{"amountMinor":"123450","currency":"INR"} = ₹1,234.50', W - 24, T_SMALL)):
        p.append(f'<text x="12" y="{274+j*12}" font-size="{T_SMALL}" fill="{STOP}">{ln}</text>')
    save("finance-model", p, H)


# ------------------------------------------------------------- 7. architecture
def architecture():
    H = 416
    p = head(H, "Component architecture — one deployable modular monolith",
             "Modules own their data and talk through service interfaces.")
    # clients
    p.append(f'<rect x="0" y="46" width="{W}" height="48" rx="5" fill="#FFFFFF" stroke="{RULE}"/>')
    p.append(f'<text x="10" y="62" font-size="{T_SMALL}" font-weight="700" fill="{INK2}" letter-spacing="1.2">CLIENTS</text>')
    cl = [("Staff web app", 10), ("Public pages", 160), ("Accessible list", 310), ("Future: 3D", 460)]
    for t, x in cl:
        p.append(f'<rect x="{x}" y="68" width="142" height="20" rx="3.5" fill="{LAV}" stroke="{LILAC}"/>')
        p.append(f'<text x="{x+71}" y="{82}" text-anchor="middle" font-size="{T_SMALL}" font-weight="600" fill="{IND}">{t}</text>')
    p.append(arrow(W / 2, 94, W / 2, 106))
    # edge
    p.append(f'<rect x="0" y="108" width="{W}" height="50" rx="5" fill="{VIO}"/>')
    p.append(f'<text x="10" y="126" font-size="{T_BODY}" font-weight="700" fill="#FFFFFF">'
             f'API edge — NestJS · versioned REST · validation · rate limiting</text>')
    for j, ln in enumerate(wrap("Session resolution → membership verification → TenantContext → permission check. "
                                "Every protected request.", W - 20, T_SMALL)):
        p.append(f'<text x="10" y="{140+j*11.5}" font-size="{T_SMALL}" fill="#E3DAFF">{ln}</text>')
    # modules 3 + 2
    mods = [("identity", "users, sessions, roles"), ("property", "floors, rooms, beds"),
            ("resident", "residents, stays"), ("billing", "charges, payments, deposits"),
            ("reporting", "read-only queries")]
    MW, GX = 196, 16
    for i, (n, s) in enumerate(mods):
        r, c = divmod(i, 3)
        x, y = c * (MW + GX), 170 + r * 56
        b, _ = box(x, y, MW, 48, n, s, "n")
        p.append(b)
    # cross-cutting
    p.append(f'<rect x="0" y="284" width="{W}" height="36" rx="5" fill="{LAV}" stroke="{LILAC}" stroke-dasharray="3 2"/>')
    p.append(f'<text x="10" y="300" font-size="{T_SMALL}" font-weight="700" fill="{IND}">'
             f'Cross-cutting: audit · notification · verification · agreement</text>')
    p.append(f'<text x="10" y="314" font-size="{T_SMALL}" fill="{INK2}">'
             f'Adapters behind interfaces with fakes: PaymentProvider, MessageChannel, ObjectStore, Clock — none active in the pilot</text>')
    # data
    p.append(f'<rect x="0" y="330" width="{W}" height="58" rx="5" fill="{IND}"/>')
    p.append(f'<text x="10" y="350" font-size="{T_HEAD}" font-weight="700" fill="#FFFFFF">'
             f'PostgreSQL 17 · Prisma 7 · versioned migrations</text>')
    for j, ln in enumerate(wrap("Scope columns on every organisation-owned row · constraints enforce financial and "
                                "occupancy invariants · schema intentionally empty today", W - 20, T_SMALL)):
        p.append(f'<text x="10" y="{366+j*12}" font-size="{T_SMALL}" fill="#C9BEF8">{ln}</text>')
    save("architecture", p, H)


# -------------------------------------------------------- 8. allocation sequence
def allocation_sequence():
    H = 392
    p = head(H, "Two staff allocate the same bed at the same moment",
             "The displayed map told both of them it was free. Exactly one allocation may survive.")
    lanes = [("Staff A", 70), ("Staff B", 230), ("API + domain", 400), ("PostgreSQL", 560)]
    for n, x in lanes:
        p.append(f'<rect x="{x-62}" y="46" width="124" height="22" rx="4" fill="{IND}"/>')
        p.append(f'<text x="{x}" y="61" text-anchor="middle" font-size="{T_SMALL}" font-weight="700" fill="#FFFFFF">{n}</text>')
        p.append(f'<line x1="{x}" y1="68" x2="{x}" y2="342" stroke="{RULE}" stroke-dasharray="3 3"/>')
    # transaction bands first, so nothing is drawn over a message
    for y, h, lab, col, bg in [(122, 94, "TRANSACTION A", OK, OKT), (244, 78, "TRANSACTION B", STOP, STOPT)]:
        p.append(f'<rect x="386" y="{y}" width="206" height="{h}" rx="4" fill="{bg}"/>')
        p.append(f'<text x="394" y="{y+12}" font-size="8.6" font-weight="700" fill="{col}" '
                 f'letter-spacing="0.6">{lab}</text>')
    steps = [(70, 400, 88, "approve(bed 203-C)", VIO), (230, 400, 108, "approve(bed 203-C)", VIO),
             (400, 560, 152, "BEGIN \u00b7 lock bed row", INK2), (560, 400, 172, "lock acquired for A", OK),
             (400, 560, 192, "re-check availability \u00b7 free", INK2),
             (400, 560, 212, "INSERT assignment \u00b7 COMMIT", OK), (560, 70, 234, "allocated", OK),
             (400, 560, 274, "BEGIN \u00b7 lock (waits)", WARN), (560, 400, 294, "lock acquired for B", INK2),
             (400, 560, 314, "re-check \u00b7 TAKEN", STOP), (560, 230, 336, "409 conflict + current state", STOP)]
    for x1, x2, y, lab, col in steps:
        d = 1 if x2 > x1 else -1
        i = col.replace("#", "")
        p.append(f'<path d="M{x1+d*3} {y}H{x2-d*5}" stroke="{col}" stroke-width="1.2" marker-end="url(#ar{i})"/>')
        p.append(f'<text x="{(x1+x2)/2}" y="{y-5}" text-anchor="middle" font-size="{T_SMALL}" fill="{col}">{lab}</text>')
    for j, ln in enumerate(wrap("The re-check runs inside the transaction against current records. A database "
                                "constraint enforces the same rule, so a code path that forgets still cannot "
                                "double-book.", W, T_SMALL)):
        p.append(f'<text x="0" y="{362+j*12}" font-size="{T_SMALL}" fill="{INK2}">{ln}</text>')
    save("allocation-sequence", p, H)


# ------------------------------------------------------------------ 9. roadmap
def roadmap():
    phases = [("P0", "Milestone 0 acceptance", "Toolchain, CI, local DB, scope guard",
               "Advisory cleared · DB + CI verified", True),
              ("P1", "Foundations", "Identity, tenancy, audit, money utilities",
               "Cross-tenant suite green on every route", False),
              ("P2", "Inventory & spatial", "Property, beds, 2D layout",
               "Concurrent allocation proven · layout validation", False),
              ("P3", "Residents & booking", "Stays, allocation, admission",
               "Atomic admission proven end to end", False),
              ("P4", "Finance", "Ledger, payments, dues, reports",
               "Money rules signed off · invariants pass", False),
              ("P5", "Pilot readiness", "Migration, restore, parallel run",
               "Reconciliation signed · restore evidence", False),
              ("P6", "Operations & platform", "Maintenance, SaaS admin, 3D map",
               "Second org onboarded with no code change", False)]
    BH, GY = 50, 10
    H = 50 + len(phases) * (BH + GY) + 56
    p = head(H, "Delivery phases and their gates",
             "Sequence and dependency only. A gate opens when its evidence exists, not on a date.")
    for i, (tag, title, sub, gate, blocked) in enumerate(phases):
        y = 50 + i * (BH + GY)
        p.append(f'<rect x="0" y="{y}" width="300" height="{BH}" rx="5" '
                 f'fill="{STOPT if blocked else "#FFFFFF"}" stroke="{STOP if blocked else RULE}" '
                 f'stroke-width="{1.5 if blocked else 1}"/>')
        p.append(f'<rect x="0" y="{y}" width="34" height="{BH}" rx="5" fill="{STOP if blocked else VIO}"/>')
        p.append(f'<rect x="28" y="{y}" width="6" height="{BH}" fill="{STOP if blocked else VIO}"/>')
        p.append(f'<text x="17" y="{y+BH/2+4}" text-anchor="middle" font-size="{T_BODY}" '
                 f'font-weight="700" fill="#FFFFFF">{tag}</text>')
        p.append(f'<text x="44" y="{y+20}" font-size="{T_BODY}" font-weight="700" fill="{IND}">{title}</text>')
        p.append(f'<text x="44" y="{y+36}" font-size="{T_SMALL}" fill="{INK2}">{sub}</text>')
        p.append(f'<polygon points="312,{y+BH/2} 322,{y+BH/2-8} 332,{y+BH/2} 322,{y+BH/2+8}" '
                 f'fill="{OKT}" stroke="{OK}"/>')
        for j, ln in enumerate(wrap(gate, W - 344, T_SMALL)[:2]):
            p.append(f'<text x="342" y="{y+BH/2+(0 if len(wrap(gate,W-344,T_SMALL)[:2])==1 else -4)+j*12}" '
                     f'font-size="{T_SMALL}" fill="{OK}">{ln}</text>')
        if i < len(phases) - 1:
            p.append(f'<path d="M150 {y+BH}V{y+BH+GY-2}" stroke="{INK2}" stroke-width="1.1" marker-end="url(#ar)"/>')
    wy = H - 44
    p.append(f'<rect x="0" y="{wy}" width="{W}" height="42" rx="5" fill="{WARNT}" stroke="{WARN}" stroke-width="0.8"/>')
    p.append(f'<text x="10" y="{wy+17}" font-size="{T_BODY}" font-weight="700" fill="{WARN}">'
             f'P0 is blocked, and everything downstream waits on it</text>')
    p.append(f'<text x="10" y="{wy+32}" font-size="{T_SMALL}" fill="{WARN}">'
             f'Unresolved advisory, no database connection, an API that has never started, CI that has never run.</text>')
    save("roadmap", p, H)


if __name__ == "__main__":
    print("regenerating diagrams at viewBox width", W)
    module_map()
    journey()
    spatial_hierarchy()
    shared_spatial()
    booking_states()
    finance_model()
    architecture()
    allocation_sequence()
    roadmap()
    print("done — floorplan-concept and dollhouse-concept are UI mocks, regenerated separately")
