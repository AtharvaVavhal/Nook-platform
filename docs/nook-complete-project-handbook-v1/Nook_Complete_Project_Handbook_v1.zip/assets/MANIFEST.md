# Manifest — nook brand asset package

| File | Type | Dimensions | Size | SHA-256 (first 12) | Purpose |
|---|---|---|---|---|---|
| `svg/nook-app-icon-indigo.svg` | SVG | viewBox 0 0 1024 1024 | 465 B | `2e775d98cd4c` | Alternate app icon on Midnight Indigo. Secondary use. |
| `svg/nook-app-icon-rounded.svg` | SVG | viewBox 0 0 1024 1024 | 479 B | `795342311a7e` | App icon with 22.27% superellipse-approximate corner radius. Web, macOS, marketing. |
| `svg/nook-app-icon.svg` | SVG | viewBox 0 0 1024 1024 | 447 B | `81792f4b1688` | PRIMARY app icon master. Full-bleed Nook Violet, white monogram. Square, no alpha, for iOS masking. |
| `svg/nook-favicon-16.svg` | SVG | viewBox 0 0 16 16 | 432 B | `265be1c6ceb5` | Pixel-tuned 16px favicon. Full-bleed, enlarged glyph so the stroke resolves. |
| `svg/nook-favicon-32.svg` | SVG | viewBox 0 0 32 32 | 435 B | `48a6ea77605d` | Pixel-tuned 32px favicon, rounded tile. |
| `svg/nook-favicon-mono.svg` | SVG | viewBox 0 0 32 32 | 396 B | `71b50d949fb0` | Transparent single-colour monogram for Safari mask-icon and monochrome contexts. |
| `svg/nook-favicon.svg` | SVG | viewBox 0 0 32 32 | 429 B | `d59c48318c83` | Favicon master, 32px viewBox. Violet rounded tile, white monogram. |
| `svg/nook-lockup-horizontal-white.svg` | SVG | viewBox 0 -40 554.32 142 | 1,005 B | `9ddb1288cce2` | Horizontal lockup reversed for dark backgrounds. |
| `svg/nook-lockup-horizontal.svg` | SVG | viewBox 0 -40 554.32 142 | 1,005 B | `b3adf8979d4c` | Symbol + wordmark, baseline aligned, horizontal. Indigo. |
| `svg/nook-lockup-stacked-white.svg` | SVG | viewBox 0 0 394.32 378 | 1,008 B | `dd259faa22c2` | Stacked lockup reversed for dark backgrounds. |
| `svg/nook-lockup-stacked.svg` | SVG | viewBox 0 0 394.32 378 | 1,008 B | `0ab3470fe256` | Symbol above centred wordmark. Indigo. For square and vertical slots. |
| `svg/nook-logo-black.svg` | SVG | viewBox 0 -40 394.32 142 | 812 B | `178ed22338b8` | Wordmark in 100% black. Single-colour print, engraving, stamps, fax. |
| `svg/nook-logo-primary-period.svg` | SVG | viewBox 0 -40 426.32 142 | 863 B | `715fc0011ff3` | Marketing-only wordmark with violet period. Not for product UI or below 32px. |
| `svg/nook-logo-primary.svg` | SVG | viewBox 0 -40 394.32 142 | 812 B | `f8e698498ce6` | Primary wordmark, Midnight Indigo. Use on white and light backgrounds. |
| `svg/nook-logo-violet.svg` | SVG | viewBox 0 -40 394.32 142 | 812 B | `91a13a92c25a` | Wordmark in Nook Violet. Restricted accent use on white or Soft Lavender only. |
| `svg/nook-logo-white-period.svg` | SVG | viewBox 0 -40 426.32 142 | 863 B | `c7a3c24d1255` | Marketing-only reversed wordmark with violet period. |
| `svg/nook-logo-white.svg` | SVG | viewBox 0 -40 394.32 142 | 812 B | `f8dbc18b1d1e` | Wordmark in Pure White. Use on Midnight Indigo, Nook Violet and dark imagery. |
| `svg/nook-social-avatar.svg` | SVG | viewBox 0 0 1024 1024 | 461 B | `7d5a69617831` | Circular-safe social avatar master, Nook Violet ground. |
| `svg/nook-symbol-black.svg` | SVG | viewBox 0 0 80 100 | 315 B | `bb88687e9b77` | Standalone n monogram, 100% black. Single-colour reproduction. |
| `svg/nook-symbol-violet.svg` | SVG | viewBox 0 0 80 100 | 315 B | `0f01225fa3de` | Standalone n monogram, Nook Violet. |
| `svg/nook-symbol-white.svg` | SVG | viewBox 0 0 80 100 | 315 B | `66d69c402d85` | Standalone n monogram, Pure White. For dark and violet grounds. |
| `svg/nook-symbol.svg` | SVG | viewBox 0 0 80 100 | 315 B | `124ec158c80c` | Standalone n monogram, Midnight Indigo. |
| `png/nook-app-icon-1024.png` | PNG RGB | 1024×1024 | 12,027 B | `7a58d59b883f` | App Store / Play Store icon. 1024x1024, RGB, NO alpha channel (store requirement). |
| `png/nook-app-icon-rounded-1024.png` | PNG RGBA | 1024×1024 | 24,104 B | `d1225244fe14` | Rounded app icon, 1024x1024, transparent outside the corner radius. |
| `png/nook-brand-board.png` | PNG RGB | 1640×2060 | 169,834 B | `026576b47b91` | Visual presentation board: light and dark lockups, palette, browser tab, app icons, dashboard header, incorrect use, small-size validation. |
| `png/nook-favicon-16.png` | PNG RGB | 16×16 | 296 B | `5e95b466da35` | Favicon 16x16. |
| `png/nook-favicon-180.png` | PNG RGBA | 180×180 | 3,460 B | `79cdcaf4f34f` | apple-touch-icon, 180x180. |
| `png/nook-favicon-192.png` | PNG RGBA | 192×192 | 3,673 B | `43dd80749ea5` | Android / PWA icon, 192x192. |
| `png/nook-favicon-32.png` | PNG RGBA | 32×32 | 585 B | `bcdc3168cc9c` | Favicon 32x32. |
| `png/nook-favicon-48.png` | PNG RGBA | 48×48 | 942 B | `c9d44058fc9e` | Favicon 48x48. |
| `png/nook-favicon-512.png` | PNG RGBA | 512×512 | 10,853 B | `5d1222461863` | PWA maskable / splash icon, 512x512. |
| `png/nook-logo-transparent.png` | PNG RGBA | 2400×864 | 70,838 B | `a76b22f6f43a` | High-resolution wordmark, Midnight Indigo, transparent background. |
| `png/nook-logo-white-transparent.png` | PNG RGBA | 2400×864 | 56,914 B | `64e02313db19` | High-resolution wordmark, white, transparent background. |
| `png/nook-social-avatar.png` | PNG RGBA | 1024×1024 | 35,692 B | `a1b4fdb81ae1` | Square social profile avatar, 1024x1024. |
| `png/nook-symbol-transparent.png` | PNG RGBA | 1200×1500 | 32,076 B | `803abee250d3` | High-resolution monogram, Midnight Indigo, transparent background. |
| `png/nook-symbol-white-transparent.png` | PNG RGBA | 1200×1500 | 26,971 B | `0c361b4dd852` | High-resolution monogram, white, transparent background. |
| `nook-brand-guidelines.md` | Markdown | — | 4,421 B | `f12c1806729d` | Approved colours, construction, clear space, minimum sizes, background usage, incorrect treatments, open items. |
| `README.md` | Markdown | — | 2,386 B | `3d7f9c56096f` | This package: which file to use where, favicon markup, editing notes. |

**38 files**, plus this manifest.

All SVGs are self-contained: correct `viewBox`, no embedded rasters, no external or remote references, no font dependencies, no live text. All letterforms are closed vector paths.

`nook-app-icon-1024.png` is RGB with no alpha channel by design — the App Store rejects icons containing transparency. Every other PNG has a transparent background outside the mark or tile.
